
</main>
<footer>
    <p class="copy">&copy; Dicampus 2025</p>
    
    <ul class="footer">
      <li><a href="cookies.php">Política de Cookies</a></li>
      <li><a href="legal.php">Política Legal</a></li>
      <li><a href="contacto.php">Contacto</a></li>
    </ul>
    

</footer>       
</body>
</html>
