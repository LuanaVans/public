<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumnos</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
    
<body>
  <header>
    <ul>
      <li><a href="index.php">Inicio</a></li>
     
      <li><a href="login.php">Login</a></li>
    </ul>
    
   
</header>
<main>