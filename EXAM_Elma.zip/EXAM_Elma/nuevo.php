




<h1>Ingrese Nuevo Alumno</h1>

<form action="nuevo.php" class="formulario">
<label for="nombre"> Nombre:</label>
<input type="text" id="nombre" name="nombre">
<label for="apellidos">Apellidos</label>
<input type="apellidos" id="apellidos" name="apellidos">
<label for="telefono">Teléfono</label>
<input type="telefono" id="telefono" name="telefono">
<label for="foto">Foto</label>
<input type="foto" id="foto" name="foto">


<button type="submit">Ingresar Alumno</button>
</form>
